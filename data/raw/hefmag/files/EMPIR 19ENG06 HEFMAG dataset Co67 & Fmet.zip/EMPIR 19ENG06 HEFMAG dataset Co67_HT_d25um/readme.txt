Sample 2: amorphous ribbon, transverse anisotropy.
Composition Co_67_Fe_4_B_14.5_Si_14.5
d	thickness	25e-6 m
Is	Saturation magnetization	0.65 T
\rho	resistivity	141e–8 Ω·m
\delta	density	7730 kg/m3
K       anisotropy constant 8.5 J/m^3

Each file "Jp_XmT" contains measurement at peak induction X performed through the flux-metric method. 
There are four columns: the frequency, the real part of permeability, the imaginary part of permeability, and the loss in J/m^3.

The file Analyzer_HF.txt contains measurements performed with the Transmission Line Method up to 1GHz using a Vector Network Analyzer (VNA) feeding a shorted 50-ohm coaxial cable, which holds the sample at its bottom. The VNA generates a frequency-swept signal and provides the frequency dependence of impedance at the sample plane. The impedance can be related to the geometry of the sample, the frequency, and the complex permeability of the core that was eventually retrieved. There are three columns for the frequency, the real part of permeability, and the imaginary part of the permeability.